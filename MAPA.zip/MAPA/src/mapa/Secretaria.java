/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapa;

/**
 *
 * @author unknow
 */
public class Secretaria extends Funcionario{
@Override
 public double calcularSalarioAnual (double decimo){
        this.salario = salario * 12 + decimo;
        return salario;
       }
@Override
       void exibirDados (){
        System.out.println("**** Scretaria ****");
        System.out.println("Nome:"+ this.nome);
        System.out.println("Documento:"+ this.documento);
        System.out.println("Total salario Anual + Decimo terceiro:"+ this.salario);    
        System.out.println("Ramal:"+this.ramal);
    
       }
}
