/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapa;

/**
 *
 * @author unknow
 */
abstract class Funcionario extends Pessoa{
       double salario;
       int ramal;
       
       public double calcularSalarioAnual (double decimo){
        this.salario = salario * 12;
        return salario + decimo;
       }
    
    @Override
    void exibirDados (){
    System.out.println("Nome:"+ this.nome);
    System.out.println("Documento:"+ this.documento);
    System.out.println("Total salario Anual + Decimo terceiro:"+ this.salario);    
    System.out.println("Ramal:"+this.ramal);
        
}
       
       

    /**
     * @return the salario
     */
    public double getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }

    /**
     * @return the ramal
     */
    public int getRamal() {
        return ramal;
    }

    /**
     * @param ramal the ramal to set
     */
    public void setRamal(int ramal) {
        this.ramal = ramal;
    }
}
