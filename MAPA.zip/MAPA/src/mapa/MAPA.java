/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapa;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author unknow
 */
public class MAPA extends Pessoa{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
        System.out.println("______________________________________________________");
        Presidente presidente = new Presidente();
        presidente.setNome("Asdrubal Leôncio Correa");
        presidente.setDocumento("123.321.345-05");
        presidente.setSalario(2000);
        presidente.calcularSalarioAnual(950);
        presidente.setRamal(100);
        presidente.exibirDados();
        System.out.println("______________________________________________________");
        
        System.out.println("______________________________________________________\n");
        Secretaria secretaria = new Secretaria();
        secretaria.setNome("Fátima");
        secretaria.setDocumento("098.986.345-01");
        secretaria.setSalario(1750);
        secretaria.calcularSalarioAnual(950);
        secretaria.setRamal(101);
        secretaria.exibirDados();
        System.out.println("\n");
        
        secretaria.setNome("Ana");
        secretaria.setDocumento("165.984.295-09");
        secretaria.setSalario(1750);
        secretaria.calcularSalarioAnual(950);
        secretaria.setRamal(101);
        secretaria.exibirDados();
        System.out.println("______________________________________________________\n");
        
        
        System.out.println("______________________________________________________\n");
        Vendedor vendedor = new Vendedor();
        vendedor.setNome("João");
        vendedor.setDocumento("138.903.762-03");
        vendedor.setSalario(1850);
        vendedor.salarioMesComComissao(750);
        vendedor.setRamal(102);
        vendedor.exibirDados();
        System.out.println("\n");
        
        vendedor.setNome("Vanessa");
        vendedor.setDocumento("059.042.095-78");
        vendedor.setSalario(1850);
        vendedor.salarioMesComComissao(550);
        vendedor.setRamal(102);
        vendedor.exibirDados();
        System.out.println("\n");
        
        vendedor.setNome("Carlos");
        vendedor.setDocumento("070.831.415-81");
        vendedor.setSalario(1850);
        vendedor.salarioMesComComissao(1100);
        vendedor.setRamal(102);
        vendedor.exibirDados();
        System.out.println("______________________________________________________\n");
        
        
        System.out.println("______________________________________________________\n");
        Cliente cliente = new Cliente();
        cliente.setNome("Marcos");
        cliente.setDocumento("095.897.594-95");
        cliente.setUsuario("marcos_2019@yahoo.com");
        cliente.setSenha("12345");
        cliente.exibirDados();
        System.out.println("\n");
        
        
        
        cliente.setNome("Joana");
        cliente.setDocumento("032.457.590-23");
        cliente.setUsuario("joana.jo1999@hotmail.com");
        cliente.setSenha("098765");
        cliente.exibirDados();
        System.out.println("\n");
        
        cliente.setNome("Elisa");
        cliente.setDocumento("490.689.489-01");
        cliente.setUsuario("elisa_123santos@gmail.com.com"); 
        cliente.setSenha("567890");
        cliente.exibirDados();
        System.out.println("\n");
        
        cliente.setNome("Lucas");
        cliente.setDocumento("132.834.467-56");
        cliente.setUsuario("lu.loko2000s@gmail.com");
        cliente.setSenha("segredo");
        System.out.println(cliente.verificaSenha("123456"));
        System.out.println(cliente.verificaSenha("teste"));
        System.out.println(cliente.verificaSenha("segredo"));
        cliente.exibirDados();
        System.out.println("______________________________________________________\n");
        
    }
    
}
