/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapa;

/**
 *
 * @author unknow
 */
public class Vendedor extends Funcionario {
    private double comissao;
    
    
    
    public double salarioMesComComissao(int comissao){
        this.salario = salario + comissao;
        return salario;
       }
    
    void exibirDados (){
    System.out.println("**** Vendedor ****");            
    System.out.println("Nome:"+ this.nome);
    System.out.println("Documento:"+ this.documento);
    System.out.println("Total salario Mês + Comissão:"+ this.salario);    
    System.out.println("Ramal:"+this.ramal);
    
    }
   
    

    /**
     * @return the comissao
     */
    public double getComissao() {
        return comissao;
    }

    /**
     * @param comissao the comissao to set
     */
    public void setComissao(double comissao) {
        this.comissao = comissao;
    }
}