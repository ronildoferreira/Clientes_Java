/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapa;

/**
 *
 * @author unknow
 */
public class Cliente extends Pessoa{
    private String usuario;
    private String senha;
    
    public Cliente(String usuario){
    this.usuario = usuario;
    }

    Cliente() {}
    
    @Override
    void exibirDados (){
        System.out.println("**** Cliente ****");
        System.out.println("Nome:"+this.nome);
        System.out.println("Documento:"+ this.documento);
        System.out.println("Usuario:"+ this.usuario);
        System.out.println("Senha:"+this.senha);
        
}
    public boolean verificaSenha(String s){
    if(s.equals("segredo")){
    System.out.println("Login Efetuado com Sucesso. -> ' "+ s +" ' - é a senha do Cliente!!!\n");
        return true;
        
    }else
    System.out.println("Erro na senha -> ' " + s+" '");
    return false;
        
    }
    
    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }
    
    

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    
   
}
